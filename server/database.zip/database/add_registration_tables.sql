-- ============================================
-- Registration System Database Tables
-- Run this after restoring SAMFinalDB.sql
-- 
-- Usage:
--   psql -d sam -U sam_user -f server/database/add_registration_tables.sql
-- ============================================

-- 1. Registration Holds Table
CREATE TABLE IF NOT EXISTS registration_holds (
    hold_id SERIAL PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    hold_type VARCHAR(50) NOT NULL CHECK (hold_type IN ('academic_advising', 'financial', 'disciplinary', 'other')),
    note TEXT,
    placed_by_user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE RESTRICT,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'removed')),
    placed_at TIMESTAMP NOT NULL DEFAULT NOW(),
    removed_at TIMESTAMP
);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_registration_holds_student_status 
    ON registration_holds(student_id, status);

-- Partial unique index to prevent duplicate active holds
CREATE UNIQUE INDEX IF NOT EXISTS idx_registration_holds_unique_active 
    ON registration_holds(student_id, hold_type) 
    WHERE status = 'active';

-- 2. Time Conflict Waivers Table
CREATE TABLE IF NOT EXISTS time_conflict_waivers (
    waiver_id SERIAL PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    class_id_1 INTEGER NOT NULL REFERENCES class_sections(class_id) ON DELETE CASCADE,
    class_id_2 INTEGER NOT NULL REFERENCES class_sections(class_id) ON DELETE CASCADE,
    instructor_approved BOOLEAN DEFAULT FALSE,
    instructor_approved_by INTEGER REFERENCES users(user_id) ON DELETE SET NULL,
    instructor_approved_at TIMESTAMP,
    advisor_approved BOOLEAN DEFAULT FALSE,
    advisor_approved_by INTEGER REFERENCES users(user_id) ON DELETE SET NULL,
    advisor_approved_at TIMESTAMP,
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'denied')),
    requested_at TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT check_different_classes CHECK (class_id_1 != class_id_2),
    CONSTRAINT unique_waiver_request UNIQUE (student_id, class_id_1, class_id_2)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_time_conflict_waivers_student 
    ON time_conflict_waivers(student_id);
CREATE INDEX IF NOT EXISTS idx_time_conflict_waivers_status 
    ON time_conflict_waivers(status);

-- 3. Prerequisite Waivers Table
CREATE TABLE IF NOT EXISTS prerequisite_waivers (
    waiver_id SERIAL PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    course_id INTEGER NOT NULL REFERENCES courses(course_id) ON DELETE CASCADE,
    waived_course_code VARCHAR(20) NOT NULL, -- e.g., 'CSE 114'
    granted_by_user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE RESTRICT,
    status VARCHAR(20) NOT NULL DEFAULT 'approved' CHECK (status IN ('approved', 'denied')),
    granted_at TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT unique_prereq_waiver UNIQUE (student_id, course_id, waived_course_code)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_prerequisite_waivers_student_course 
    ON prerequisite_waivers(student_id, course_id);

-- 4. Department Permissions Table
CREATE TABLE IF NOT EXISTS department_permissions (
    permission_id SERIAL PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    course_id INTEGER NOT NULL REFERENCES courses(course_id) ON DELETE CASCADE,
    granted_by_user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE RESTRICT,
    status VARCHAR(20) NOT NULL DEFAULT 'approved' CHECK (status IN ('approved', 'denied')),
    granted_at TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT unique_department_permission UNIQUE (student_id, course_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_department_permissions_student 
    ON department_permissions(student_id);
CREATE INDEX IF NOT EXISTS idx_department_permissions_course 
    ON department_permissions(course_id);

-- 5. Registration Schedules Table
CREATE TABLE IF NOT EXISTS registration_schedules (
    schedule_id SERIAL PRIMARY KEY,
    term_id INTEGER NOT NULL REFERENCES terms(term_id) ON DELETE CASCADE,
    class_standing VARCHAR(2) NOT NULL CHECK (class_standing IN ('U1', 'U2', 'U3', 'U4')),
    credit_threshold INTEGER, -- NULL means no credit threshold
    registration_start_date DATE NOT NULL,
    CONSTRAINT unique_registration_window UNIQUE (term_id, class_standing, credit_threshold)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_registration_schedules_term 
    ON registration_schedules(term_id);
CREATE INDEX IF NOT EXISTS idx_registration_schedules_term_standing 
    ON registration_schedules(term_id, class_standing);

-- 6. Capacity Overrides Table
CREATE TABLE IF NOT EXISTS capacity_overrides (
    override_id SERIAL PRIMARY KEY,
    student_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    class_id INTEGER NOT NULL REFERENCES class_sections(class_id) ON DELETE CASCADE,
    granted_by_user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE RESTRICT,
    granted_at TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT unique_capacity_override UNIQUE (student_id, class_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_capacity_overrides_student 
    ON capacity_overrides(student_id);
CREATE INDEX IF NOT EXISTS idx_capacity_overrides_class 
    ON capacity_overrides(class_id);

-- ============================================
-- Verification Query (uncomment to run)
-- ============================================
-- SELECT table_name 
-- FROM information_schema.tables 
-- WHERE table_schema = 'public' 
--   AND table_name IN (
--     'registration_holds',
--     'time_conflict_waivers',
--     'prerequisite_waivers',
--     'department_permissions',
--     'registration_schedules',
--     'capacity_overrides'
--   )
-- ORDER BY table_name;

